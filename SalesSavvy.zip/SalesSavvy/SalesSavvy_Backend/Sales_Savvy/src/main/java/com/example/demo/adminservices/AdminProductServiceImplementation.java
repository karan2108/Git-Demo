package com.example.demo.adminservices;

import java.util.Optional;
import java.math.BigDecimal;
import java.time.LocalDateTime;


import org.springframework.stereotype.Service;

import com.example.demo.entity.Product;
import com.example.demo.entity.ProductImage;
import com.example.demo.entity.Category;
import com.example.demo.repository.CategoryRepository;
import com.example.demo.repository.ProductImageRepository;
import com.example.demo.repository.ProductRepository;

@Service
public class AdminProductServiceImplementation implements AdminProductService {

	private final ProductRepository productRepository;
	private final ProductImageRepository productImageRepository;
	private final CategoryRepository categoryRepository;
	
	public AdminProductServiceImplementation(ProductRepository productRepository, ProductImageRepository productImangeRepository, CategoryRepository categoryRepository) {
		this.productRepository = productRepository;
		this.productImageRepository = productImangeRepository;
		this.categoryRepository = categoryRepository;
	}
	@Override
	public Product addProductWithImage(String name, String description, Double price, Integer stock,
			Integer cartegoryId, String imageUrl) {
		
		// Validate the category 
		Optional<Category> category = categoryRepository.findById(cartegoryId);
		if (category.isEmpty()) {
			throw new IllegalArgumentException("Invalid category ID");
		}
		
		// Create and save the product
		Product product = new Product();
		product.setName(name);
		product.setDescription(description);
		product.setPrice(BigDecimal.valueOf(price));
		product.setStock(stock);
		product.setCategory(category.get());
		product.setCreatedAt(LocalDateTime.now());
		product.setUpdatedAt(LocalDateTime.now());
		
		Product saveProduct = productRepository.save(product);
		
		// Create and save the product image
		if (imageUrl != null && !imageUrl.isEmpty()) {
			ProductImage productImage = new ProductImage();
			productImage.setProduct(saveProduct);
			productImage.setImageUrl(imageUrl);
			productImageRepository.save(productImage);
		}
		else {
			throw new IllegalArgumentException("Product image URL cannot br empty");
		}
		
		
		
		return saveProduct;
	}

	@Override
	public void deleteProduct(Integer productId) {
		// Check if product exists
		if (!productRepository.existsById(productId)) {
			throw new IllegalArgumentException("Product nor found");
		}
		
		// Delete associated product images 
		productImageRepository.deleteByProductId(productId);
		
		// Delete the product
		productRepository.deleteById(productId);
	}

}
