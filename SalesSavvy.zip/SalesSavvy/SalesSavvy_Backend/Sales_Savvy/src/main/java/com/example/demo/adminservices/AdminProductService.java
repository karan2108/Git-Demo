package com.example.demo.adminservices;

import com.example.demo.entity.Product;

public interface AdminProductService {

	public Product addProductWithImage(String name, String description, Double price, Integer stock, Integer cartegoryId, String imageUrl);
	
	public void deleteProduct(Integer productId);
}
