package com.example.demo.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.LoginRequest;
import com.example.demo.entity.User;
import com.example.demo.service.AuthServiceImplementation;

import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@RestController
@CrossOrigin(origins = "http://localhost:5173", allowCredentials = "true")
@RequestMapping("/api/auth")
public class AuthController {

	private final AuthServiceImplementation authService;
	
	public AuthController(AuthServiceImplementation authService) {
		// TODO Auto-generated constructor stub
		this.authService = authService;
	}
	
	@PostMapping("/login")
	public ResponseEntity<?> login(@RequestBody LoginRequest loginRequest, HttpServletResponse response) {
		
		try {
			// Authenticate user and get the role
			User user = authService.authenticate(loginRequest.getUsername(), loginRequest.getPassword());
			
			// Generate JWT token
			String token = authService.generateToken(user);
			
			// Set token as HttpOnly cookie
			Cookie cookie = new Cookie("authToken", token);
			cookie.setHttpOnly(true);
			cookie.setSecure(false); // Set true in production with HTTPS
			cookie.setPath("/");
			cookie.setMaxAge(3600); // 1 hour
			cookie.setDomain("localhost"); 	// Optional but useful
			response.addCookie(cookie);
			
			response.addHeader("Set-Cookie",
                    String.format("authToken=%s; HttpOnly; Path=/; Max-Age=3600; SameSite=None", token));

			// Return user role in response body
			Map<String, String> responseBody = new HashMap<>();
			responseBody.put("message", "Login successful");
			responseBody.put("role", user.getRole().name());
			responseBody.put("username", user.getUsername());
			
			
			return ResponseEntity.ok(responseBody);

		}
		catch(RuntimeException e) { 
			return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(Map.of("error", e.getMessage()));
		}
		
	}
	
	
	@PostMapping("/logout")
	public ResponseEntity<Map<String, String>> logout(HttpServletRequest request, HttpServletResponse response) {
		try {
			// Retrieve authenticated user from the request
			User user = (User) request.getAttribute("authenticatedUser");
			System.out.println(user);
			
			
			// Delegate logout operation to the service layer
			authService.logout(user);
			System.out.println("Logout Successful");
			
			// Clear the authenticated token cookie
			Cookie cookie = new Cookie("authToken", null);
			cookie.setHttpOnly(true);
			cookie.setMaxAge(0);
			cookie.setPath("/");
			response.addCookie(cookie);
			
			// Success response 
			Map<String, String> responseBody = new HashMap<>();
			responseBody.put("message", "Logout successful");
			return ResponseEntity.ok(responseBody);
		}
		catch (RuntimeException e) {
			// Error response 
			Map<String, String> errorResponse = new HashMap<>();
			errorResponse.put("message", "Logout failed");
			return ResponseEntity.status(500).body(errorResponse);
		}
	}
}
