package com.example.demo.service;

public interface CartService {

	public int getCartItemCount(int userId);
	
	public void addToCart(int userId, int productId, int quantity);
	
}
