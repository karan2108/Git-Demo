
import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom';

export default function VerifyOtp() {
    const [otp, setOTP] = useState('');
    const [message, setMessage] = useState('');
    const [error, setError] = useState('');
    const navigate = useNavigate();

    const handleOTPVerify = async (e) => {
        e.preventDefault();
        try {
            const response = await fetch("http://localhost:9090/api/auth/verifyOtp",{
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({otp}),
            });

            if (response.ok) {
                const data = await response.json();
                setMessage(data.message);
                const userId = data.userId;
                navigate('/setNewPassword', {state: {userId}})

            } else {
                const errmsg = await response.json();
                setError(errmsg.message);
            }

        } catch (error) {
            setError("An Unexpected error occurred.")
            setMessage("");
        }
    }
  return (
    <div>
       <div className='page-container'>
        <div className='form-container'>
            <h1 className='form-title'>Verify OTP</h1>
            {message && <p className='success-message'>{message}</p>} 

            {error && <p className='error-message'>{error}</p>}
            
            <form onSubmit={handleOTPVerify} className='form-content'>
                <div className='form-group'>
                    <label htmlFor='otp' className='form-label'>Enter OTP</label>
                    <input id='otp' type='text' placeholder='Enter OTP' value={otp} onChange={(e) => setOTP(e.target.value)} required className='form-input'></input>
                </div>

                <div>
                    <button type='submit' className='form-button'>Verify OTP</button>
                </div>
            </form>


         </div>
        </div>
    </div>
  )
}
