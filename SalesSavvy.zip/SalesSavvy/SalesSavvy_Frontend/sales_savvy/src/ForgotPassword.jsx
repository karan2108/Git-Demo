import React, { useState } from 'react'
import './assets/styles.css'
import {useNavigate} from 'react-router-dom';



export default function ForgotPassword() {
    const [email, setEmail] = useState('');
    const [message, setMessage] = useState('');
    const [error, setError] = useState('');
    const navigate = useNavigate();


    const handleForgotPassword = async (e) => {
        e.preventDefault();
        try {
            const response = await fetch("http://localhost:9090/api/auth/forgotPassword", {
                method:"POST",
                headers: {
                    "Content-Type":"application/json",
                },
                body: JSON.stringify({email}),
            });

            if (response.ok) {
                const data = await response.json();
                setMessage(data.message);
                navigate('/verifyOtp')
            } else {
                const errmsg = await response.json();
                setError(errmsg.message);
            }

        } catch (error) {
            setError("An Unexpected error occurred.");
            setMessage("");
            
        }
    }
  return (
    <div>
      <div className='page-container'>
        <div className='form-container'>
            <h1 className='form-title'>Forgot Password</h1>
            {message && <p className='success-message'>{message}</p>} 

            {error && <p className='error-message'>{error}</p>}
            
            <form onSubmit={handleForgotPassword} className='form-content'>
                <div className='form-group'>
                    <label htmlFor='email' className='form-label'>Enter Email</label>
                    <input 
                        id='email' 
                        type='text' 
                        placeholder='Enter email associated with the account' 
                        value={email} 
                        onChange={(e) => setEmail(e.target.value)} 
                        required 
                        className='form-input'>
                    </input>
                </div>

                <div>
                    <button type='submit' className='form-button'>Submit</button>
                </div>
            </form>
        </div>
    </div>
    </div>
  )
}
