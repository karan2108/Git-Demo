import React from 'react';
import { Routes, Route } from 'react-router-dom';
import RegistrationPage from './RegistrationPage';
import LoginPage from './LoginPage';
import ForgotPassword from './ForgotPassword';
import VerifyOtp from './VerifyOtp';
import NewPassword from './NewPassword';
import CustomerHomePage from './CustomerHomePage';
import CartPage from './CartPage';
import OrderPage from './OrderPage';
import AdminLoginPage from './AdminLoginPage';
import AdminDashboard from './AdminDashboard';

const AppRoutes = () => {
    return (
        <Routes>
            <Route path="/" element={<LoginPage />} />
            <Route path="/register" element={<RegistrationPage />} />
            <Route path="/login" element={<LoginPage />} />
            <Route path="/forgot-Password" element={<ForgotPassword/>}/>
            <Route path="/verifyOtp" element={<VerifyOtp/>}/>
            <Route path="/setNewPassword" element={<NewPassword/>}/>
            <Route path="/customerhome" element={<CustomerHomePage/>} />
            <Route path="/UserCartPage" element={<CartPage />} />
            <Route path="/orders" element={<OrderPage />} />
            <Route path="/admin" element={<AdminLoginPage />} />
            <Route path="/admindashboard" element={<AdminDashboard />} />
            {/*Add more routes here as your app grows */}
        </Routes>
    );
};

export default AppRoutes;