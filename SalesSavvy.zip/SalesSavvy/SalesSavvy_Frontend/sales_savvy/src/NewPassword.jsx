import React, { useState } from 'react'
import { useLocation } from 'react-router-dom';

export default function NewPassword() {

    const location = useLocation();
    const userId = location.state?.userId || '';
    const [newPassword, setNewPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [message, setMessage] = useState('');
    const [error, setError] = useState('');

    const handleNewPassword = async (e) => {
        e.preventDefault();

        if (newPassword !== confirmPassword) {
            setError("Passwords do not match");
            setMessage('');
            return;
        }

        try {
            const response = await fetch("http://localhost:9090/api/auth/setNewPassword", {
                method:"POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({
                    userId,
                    password: newPassword,
                }),
            });

            if (response.ok) {
                const data = await response.json();
                setMessage(data.message);
                setError('');
            } else {
                const errMsg = await response.json();
                setError(errMsg.message);
                setMessage('');
            }
        } catch (error) {
            setError("An Unexpected error occurred");
            setMessage('');
        }
    }

  return (
    <div className='page-container'>
        <div className='form-container'>
            <h1 className='form-title'>Set Password</h1>
            {error && <p className='error-message'>{error}</p>}
            {message && <p className='success-message'>{message}</p>}
            
            <form onSubmit={handleNewPassword} className='form-content'>
                
                <div className='form-group'>
                    <label htmlFor='newPassword' className='form-label'>New Password</label>
                    <input id='newPassword' type='password' placeholder='Enter new password' value={newPassword} onChange={(e) => setNewPassword(e.target.value)} required className='form-input'></input>
                </div>

                <div className='form-group'>
                    <label htmlFor='confirmPassword' className='form-label'>Confirm Password</label>
                    <input id='confirmPpassword' type='password' placeholder='Confirm new password' value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} required className='form-input'></input>
                </div>

                <div>
                    <button type='submit' className='form-button'>Submit</button>
                </div>
            </form>


            <div className='form-footer'>
                <a href='/login' className='form-link'>Go To Login</a>
            </div>


         </div>
  
</div>

  )
}
